I am adding assignments to the book so that readers can practice after reading each chapter.
This may take a while to complete for the whole book.
Please also read the comments in the assignments because I might use new functions or formulas in the assignments.

For this chapter's assignment, assume that there are 155 cancer patients, 
they can be clustered into different survival groups based on their gene expression levels.
In this assignment, there are 25 genes and we assume that these 25 genes are revelant.
